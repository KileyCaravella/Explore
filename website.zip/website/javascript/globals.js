
var globals = {
  CLIENT_ID: "4NMYNrNO_HRZm9u9mPlH2w",
  CLIENT_SECRET: "roPjBQkz8jRRaIhpw8ScW4y1Z875JJTe22tPF2mKSo7EIoKcW0wNKLp3wFz9yyAF",
  TOKEN: "",
  BASE_URL: "api.yelp.com",
  AUTH_URL: "/oauth2/token",
  BUSINESS_URL: "/v3/businesses/search?",
  BUSINESS_LIMIT: "5"
}

module.exports = globals;
