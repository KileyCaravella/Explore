<?php
/**
 * Created by PhpStorm.
 * User: Kiley
 * Date: 3/16/17
 */

// database connection variables

define("RDS_HOSTNAME", "activityfinder.czq9iwajyy1p.us-east-1.rds.amazonaws.com");
define("RDS_PORT", "3306");
define("RDS_USERNAME", "Kiley");
define("RDS_PASSWORD", "BentleyCS460");
define("RDS_DB_NAME", "ActivityFinderDB");

?>