<?php
/**
 * Created by PhpStorm.
 * User: Kiley
 * Date: 3/16/17
 */
session_start();
// define sql constant for various event type
$user_id = $_SESSION['user_id'];
