<?php

print("This is to test php functionality. To run, type into a browser localhost/test.php");
